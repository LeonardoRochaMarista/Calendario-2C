function colorirData(){
    let days    = document.getElementById('day').value;
    let color   = document.getElementById('color').value;
    let calendar = document.getElementById('calendar');

}

// getElementsByTagName
// Em qual elemento/tag os dias estão escritos?
// Como mudar estilo css com Javascript 